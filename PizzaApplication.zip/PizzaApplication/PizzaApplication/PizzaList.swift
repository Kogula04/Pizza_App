//
//  PizzaList.swift
//  PizzaApplication
//
//  Created by Kogula on 2023-03-01.
//

import SwiftUI

struct PizzaList: View {
    
    @ObservedObject var viewModel: PizzaViewModel
    
    @State private var selectedIndex = 0
    @State private var isSheetShowing = false
    
    var body: some View {
        NavigationStack {
            VStack{
                Text("Pizzas")
                    .font(.title)
                    .bold()
                
                Picker("Pizza", selection: $selectedIndex) {
                    Text("All").tag(0)
                    Text("Meat").tag(1)
                    Text("Veggie").tag(2)
                }
                .pickerStyle(.segmented)
                
                List {
                    if selectedIndex == 0 {
                        ForEach(viewModel.savedPizzaData) { pizza in
                            NavigationLink {
                                SinglePizzaView(selectedPizzaItem: pizza, viewModel: viewModel)
                            }label: {
                                HStack {
                                    Image("\(pizza.imageName ?? "")")
                                        .resizable()
                                        //.scaledToFit()
                                        .frame(width: 100, height: 100)
                                        //.frame(width: 200, height: 200, alignment: .leading)
                                    Text("\(pizza.name ?? "")")
                                    
//                                    Text("\(pizza.isFavourite.description)")
                                }
                                
                            }
                        }
                        
                    } else if selectedIndex == 1{
                        ForEach(viewModel.filterPizzaWithType(pizzaType: "Meat")) { pizza in
                            HStack {
                                Image("\(pizza.imageName ?? "")")
                                    .resizable()
                                    //.scaledToFit()
                                    .frame(width: 100, height: 100)
                                    //.frame(width: 200, height: 200, alignment: .leading)
                                Text("\(pizza.name ?? "")")
                            }
                        }
                        
                    }else {
                        ForEach(viewModel.filterPizzaWithType(pizzaType: "vegetarian")) { pizza in
                            HStack {
                                Image("\(pizza.imageName ?? "")")
                                    .resizable()
                                    //.scaledToFit()
                                    .frame(width: 100, height: 100)
                                    //.frame(width: 200, height: 200, alignment: .leading)
                                Text("\(pizza.name ?? "")")
                            }
                        }
                        
                    }
                }
                .listStyle(.plain)
        
                
//                HStack {
//                    Image("veg_supreme")
//                        .resizable()
//                        .scaledToFit()
//                        .frame(width: 200, height: 200, alignment: .leading)
//                    Text("Veg Supreme")
//                }
                Spacer()
            }
            
            .toolbar {
                ToolbarItem {
                    Button {
                        //action
                        isSheetShowing.toggle()
                    } label: {
                        Image(systemName: "plus")
                    }
                }
            }
            .sheet(isPresented: $isSheetShowing) {
                AddNewPizza(viewModel: viewModel)
            }
            
        }
        
    }
}

struct PizzaList_Previews: PreviewProvider {
    static var previews: some View {
        PizzaList(viewModel: PizzaViewModel())
    }
}
