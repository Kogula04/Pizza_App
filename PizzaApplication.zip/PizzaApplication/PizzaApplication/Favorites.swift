//
//  Favorites.swift
//  PizzaApplication
//
//  Created by Kogula on 2023-03-01.
//

import SwiftUI

struct Favorites: View {
    @ObservedObject var viewModel: PizzaViewModel
    
    var body: some View {
        NavigationStack {
            List {
                ForEach(viewModel.filterFavouritePizza()) { pizza in
                    HStack {
                        Image("\(pizza.imageName ?? "")")
                            .resizable()
                        //.scaledToFit()
                            .frame(width: 100, height: 100)
                        //.frame(width: 200, height: 200, alignment: .leading)
                        Text("\(pizza.name ?? "")")
                    }
                }
//                .onDelete(perform: viewModel.deletePizza)
                .onDelete { indexSet in
                    viewModel.deletePizza(indexSet: indexSet)
                }
            }
            .listStyle(.plain)
            .navigationTitle("Favourite Pizzas")
            .navigationBarTitleDisplayMode(.large)
        }
    }
}

struct Favorites_Previews: PreviewProvider {
    static var previews: some View {
        Favorites(viewModel: PizzaViewModel())
    }
}
