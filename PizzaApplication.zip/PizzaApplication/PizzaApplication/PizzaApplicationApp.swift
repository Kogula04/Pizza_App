//
//  PizzaApplicationApp.swift
//  PizzaApplication
//
//  Created by Kogula on 2023-03-01.
//

import SwiftUI

@main
struct PizzaApplicationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
