//
//  ContentView.swift
//  PizzaApplication
//
//  Created by Kogula on 2023-03-01.
//

import SwiftUI

struct ContentView: View {
    
    @StateObject var viewModel = PizzaViewModel()
    
    var body: some View {
        TabView {
            PizzaList(viewModel: viewModel).tabItem {
                Label("Pizza List", systemImage: "list.bullet")
            }
            
            Favorites(viewModel: viewModel).tabItem {
                Label("Favorites", systemImage: "star.fill")
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
